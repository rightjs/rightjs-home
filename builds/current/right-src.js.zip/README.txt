RightJS Two-Files Build Usage
------------------------------

 1. Copy both of the JavaScript files into your javascript directory,
    keep them next to each other.

 2. Include the bigger one on your page in usual way
    <script src="where/is/that/right.js"></script>

    Don't bother about the second file, it will be loaded automatically when needed

 3. Keep the filenames in a corresponding manner, like that

    right[boo-boo-boo].js
    right-olds[boo-boo-boo].js

--
Have Fun!

