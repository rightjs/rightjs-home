/**
 * RightJS UI Internationalization: US English module
 *
 * Copyright (C) Nikolay Nemshilov
 */
if (self.Calendar) {
  RightJS.$ext(self.Calendar.Options, {
    firstDay: 0,
    format:   'US'
  });
}
